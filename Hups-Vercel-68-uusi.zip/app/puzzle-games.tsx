'use client';
import {useEffect,useMemo,useRef,useState} from 'react';
import {random,shuffle} from '../libgame';
import {PieceFill} from './piece-fill';
import {Character,characters} from './characters';
import {codeLayout,codeDirections,codeStep,memoryLayout,majorityLayout,parcelLayout,cupMoves,cupPositions,lightSeries,pipeLayout,pipeRoute,turnPorts,slideLayout,moveBlock,slideMinimum,lineGraph,polygon,clipPolygon,splitRatio,windingMaze,moveMarble,inkColors,P,Block} from '../puzzle-logic';
type Props={seed:number,easy:boolean,kids:boolean,ms:number,blocked:()=>boolean,finish:(score:number,text:string)=>void};
const names=['Vieterö','Pörhö','Moukku','Löllö','Nuppu','Töppö','Lankakerä','Ilmapallo'];
function Face({id,kids=false}:{id:number,kids?:boolean}){return id<6?kids?<span className="puzzle-kid-face" role="img" aria-label={['Kuje','Kerä','Salama','Räyhä','Tassu','Hauva'][id]} style={{backgroundImage:`url('/little-friend-${id}.png')`}}/>:<Character id={id}/>:<span className="puzzle-object" aria-label={names[id]}>{['🧶','🎈'][id-6]}</span>;}
export function PuzzleGame({id,seed=1,level='normal',kids=false,avatar=0,onFinish}:{id:string,seed?:number,level?:string,kids?:boolean,avatar?:number,onFinish:(score:number,text:string)=>void}){
 const easy=level==='easy'||kids,[ms,setMs]=useState(0),[ready,setReady]=useState(id!=='tilt'),[result,setResult]=useState<{score:number,text:string}|null>(null);const done=useRef(false),callback=useRef(onFinish),started=useRef(0),delay=useRef<any>(null);callback.current=onFinish;
 const wait=id==='cups'?6500:0,limit=kids?Infinity:id==='majority'||id==='cups'?5000:id==='bisect'?15000:id==='coderoute'||(id==='slide'&&!easy&&seed%3===1)?45000:30000;
 function finish(score:number,text:string){if(done.current)return;done.current=true;const value=Math.round(Math.max(0,Math.min(1000,score)));setResult({score:value,text});const seconds=(Math.max(0,performance.now()-started.current-wait)/1000).toLocaleString('fi-FI',{minimumFractionDigits:1,maximumFractionDigits:1});delay.current=setTimeout(()=>callback.current(value,kids?text:`${text} Aika ${seconds} s.`),kids?650:id==='pipes'&&value>0?3000:1250);}
 useEffect(()=>{if(!ready)return;started.current=performance.now();const t=setInterval(()=>{if(done.current)return;const n=performance.now()-started.current;setMs(n);if(id!=='speedlights'&&n>=limit+wait)finish(0,'Hupsista! Aika loppui — 0 pistettä.');},25);return()=>clearInterval(t);},[ready]);
 useEffect(()=>()=>clearTimeout(delay.current),[]);
 const p:Props={seed,easy,kids,ms,blocked:()=>done.current||!ready,finish:(score,text)=>finish(id==='speedlights'||id==='slide'||id==='bisect'?score:score/(1+Math.max(0,ms-wait)/45000),text)};
 return <div className={'puzzle-game puzzle-'+id+(kids?' puzzle-kids':'')+(result&&result.score>0?' puzzle-solved':'')}>
 {!kids&&ready&&<div className="puzzle-clock"><span>{ms<wait?'Seuraa tarkasti…':Math.max(0,Math.ceil((limit-Math.max(0,ms-wait))/1000))+' s'}</span><i style={{width:Math.max(0,100*(1-Math.max(0,ms-wait)/limit))+'%'}}/></div>}
 {id==='piecefill'&&<PieceFill {...p}/>}
 {id==='colorsort'&&<ColorSort {...p}/>}
 {id==='coderoute'&&<CodeRoute {...p} avatar={avatar}/>}
 {id==='memorypairs'&&<Memory {...p}/>}{id==='parcel'&&<Parcel {...p}/>}{id==='speedlights'&&<Lights {...p}/>}{id==='pipes'&&<Pipes {...p} avatar={avatar}/>}{id==='majority'&&<Majority {...p}/>}{id==='slide'&&<Slide {...p}/>}{id==='onestroke'&&<OneStroke {...p}/>}{id==='cups'&&<Cups {...p}/>}{id==='bisect'&&<Bisect {...p}/>}{id==='tilt'&&<Tilt {...p} active={ready} onStart={()=>setReady(true)}/>}
 </div>;
}
export function Memory(p:Props){const pairs=p.kids?4:p.easy?6:8,layout=useMemo(()=>memoryLayout(p.seed,pairs),[p.seed,pairs]);const [open,setOpen]=useState<number[]>([]),[matched,setMatched]=useState<number[]>([]),[tries,setTries]=useState(0);const current=useRef<number[]>([]),found=useRef(new Set<number>()),lock=useRef(false),attempts=useRef(0),timeout=useRef<any>(null);useEffect(()=>()=>clearTimeout(timeout.current),[]);
 function pick(i:number){if(p.blocked()||lock.current||current.current.includes(i)||found.current.has(layout[i]))return;const a=[...current.current,i];current.current=a;setOpen(a);if(a.length!==2)return;attempts.current++;setTries(attempts.current);if(layout[a[0]]===layout[a[1]]){found.current.add(layout[i]);setMatched([...found.current]);current.current=[];setOpen([]);if(found.current.size===pairs)p.finish(Math.max(250,1000-Math.max(0,attempts.current-pairs)*45),'Kaikki kuvaparit löytyivät!');}else{lock.current=true;timeout.current=setTimeout(()=>{current.current=[];setOpen([]);lock.current=false;},p.kids?800:450);}}
 return <><p className="puzzle-instruction">Etsi kaksi täysin samaa kuvaa.</p><div className="memory-board" style={{gridTemplateColumns:'repeat(4,1fr)'}}>{layout.map((v,i)=>{const visible=open.includes(i)||matched.includes(v);return <button key={i} aria-label={visible?names[v]:`Käännä kortti ${i+1}`} aria-pressed={visible} className={(visible?'revealed ':'')+(matched.includes(v)?'matched':'')} onClick={()=>pick(i)}>{visible?<Face id={v} kids={p.kids}/>:<span className="card-back">?</span>}</button>;})}</div><p className="puzzle-note">{matched.length} / {pairs} paria{!p.kids&&` · ${tries} yritystä`}</p></>;
}
export function Parcel(p:Props){const n=p.kids?2:p.easy?3:4,layout=useMemo(()=>parcelLayout(p.seed,n),[p.seed,n]),[hint,setHint]=useState(''),[show,setShow]=useState(false);const answer=layout.paths[layout.target].at(-1)!,gap=260/n,x=(i:number)=>20+gap/2+i*gap;const d=(a:number[])=>a.map((v,i)=>{
  const y=40+i*48;
  return i?`C${x(a[i-1])},${y+(i%2?9:-35)} ${x(v)},${y-(i%2?80:20)} ${x(v)},${y}`:`M${x(v)},${y}`;
 }).join(' ');
 return <><p className="puzzle-instruction">Seuraa paketin narua. Kenelle yllätys kuuluu?</p><div className="parcel-stage"><svg viewBox="0 0 300 310" aria-label="Risteilevät pakettinarut">{layout.paths.map((a,i)=><path key={i} d={d(a)} fill="none" stroke="#bba3d9" strokeWidth="6" strokeLinejoin="round" strokeLinecap="round"/>)}{show&&<path d={d(layout.paths[layout.target])} fill="none" stroke="#d3ff80" strokeWidth="8" className="parcel-trace"/>}<text x={x(layout.target)} y="30" textAnchor="middle" fontSize="32">🎁</text>{layout.paths.map((_,i)=><circle key={i} cx={x(i)} cy="288" r="5" fill="#f4c8e9"/>)}</svg><div className="parcel-friends" style={{gridTemplateColumns:`repeat(${n},1fr)`}}>{Array.from({length:n},(_,i)=><button key={i} aria-label={`Paketti hahmolle ${names[i]}`} onClick={()=>{if(p.blocked())return;if(i===answer){setShow(true);p.finish(1000,'Paketti löysi oikean kaverin!');}else setHint('Hupsista, seuraa narua uudelleen!');}}><Face id={i} kids={p.kids}/>{show&&i===answer&&<span className="gift-reward">{['🎈','🧶','🍪','⭐'][i]}</span>}</button>)}</div></div><p role="status" className="puzzle-note">{hint||'Katse seuraa, sormi valitsee.'}</p></>;
}
export function Lights(p:Props){const series=useMemo(()=>lightSeries(p.seed),[p.seed]),[hits,setHits]=useState(0),consumed=useRef(0),hitsRef=useRef(0);
 const flashMs=450;
 const expected=series[consumed.current];
 const lit=new Set(series.filter((light,index)=>index>=consumed.current&&light.at<=p.ms&&p.ms-light.at<flashMs).map(light=>light.key));
 useEffect(()=>{if(p.ms>=30000&&!p.blocked())p.finish(Math.min(1000,hitsRef.current*25),`${hitsRef.current} oikeaa valoa!`);},[p.ms]);
 function hit(i:number){if(p.blocked()||!expected||expected.at>p.ms)return;if(expected.key!==i){p.finish(Math.min(1000,hitsRef.current*25),`Vauhti vei mukanaan! ${hitsRef.current} oikeaa valoa.`);return;}consumed.current++;hitsRef.current++;setHits(hitsRef.current);}
 return <><p className="puzzle-instruction">Paina valot syttymisjärjestyksessä. Tahti kiihtyy!</p><strong className="light-count">{hits}</strong><div className="speed-pads">{['#bc9ae7','#83deea','#f5a4c8','#d2f574'].map((c,i)=><button key={i} aria-label={['Violetti valo','Sininen valo','Vaaleanpunainen valo','Vihreä valo'][i]} className={lit.has(i)?'lit':''} style={{'--ink':c} as React.CSSProperties} onPointerDown={e=>{e.preventDefault();hit(i);}} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();hit(i);}}}></button>)}</div><p className="puzzle-note">Väärä painallus päättää pelin. Kerätyt pisteet säilyvät.</p></>;
}
export function Pipes(p:Props & {avatar?:number}){const paint=characters[p.avatar??0]?.color??'#82dfea';const initial=useMemo(()=>pipeLayout(p.seed,p.easy),[p.seed,p.easy]),[cells,setCells]=useState(initial.cells),[route,setRoute]=useState<number[]|null>(null);const current=useRef(initial.cells);
 function turn(i:number){if(p.blocked()||route)return;const next=current.current.map((v,j)=>j===i?{...v,turn:(v.turn+1)%4}:v);current.current=next;setCells(next);const path=pipeRoute(next);if(path){setRoute(path);p.finish(1000,'Maali löysi reitin — spläts!');}}
 return <><p className="puzzle-instruction">Käännä putkia napauttamalla. Yhdistä maali ylhäältä alas!</p><div className="pipe-layout"><div className="pipe-terminals">
 <svg className="pipe-inlet" viewBox="0 0 64 58" role="img" aria-label="Maalikannu ja putken lähtö">
  <path d="M32 33v25" stroke="#9e7cbb" strokeWidth="15"/><path d="M32 33v25" stroke={paint} strokeWidth="8"/>
  <path d="M13 14q-9-13 19-13t19 13" fill="none" stroke="#e9c7f4" strokeWidth="3"/>
  <path d="M10 14h44l-6 26H16Z" fill={paint} stroke="#e9c7f4" strokeWidth="3"/>
  <path d="M13 21h38" stroke="#d6fbff" strokeWidth="4" strokeLinecap="round"/>
 </svg></div><div className="pipe-board">{cells.map((c,i)=>{
  const ports=turnPorts(c.ports,c.turn);
  const index=route?.indexOf(i)??-1;
  const edge=(port:number)=>`${[35,70,35,0][port]} ${[0,35,70,35][port]}`;
  const prev=index>0?route![index-1]:-4;
  const inlet=prev===i-4?0:prev===i+1?1:prev===i+4?2:3;
  const outlet=ports.find(port=>port!==inlet)!;
  const outline=`M${edge(ports[0])} L35 35 L${edge(ports[1])}`;
  return <button key={i} aria-label={`Käännä putki ${i+1}`} onClick={()=>turn(i)}>
   <svg viewBox="0 0 70 70">
    <path d={outline} fill="none" stroke="#9e7cbb" strokeWidth="20" strokeLinejoin="round"/>
    <path d={outline} fill="none" stroke="#392741" strokeWidth="10" strokeLinejoin="round"/>
    {index>=0&&<path className="pipe-paint" pathLength="1" style={{animationDelay:`${index*.14}s`}} d={`M${edge(inlet)} L35 35 L${edge(outlet)}`} fill="none" stroke={paint} strokeWidth="10" strokeLinejoin="round"/>}
   </svg>
  </button>;
 })}</div><div className="pipe-terminals">
 <svg className="pipe-outlet" viewBox="0 0 64 32" role="img" aria-label="Putken ulostulo">
  <path d="M32 0v16" stroke="#9e7cbb" strokeWidth="15"/><path d="M32 0v16" stroke={paint} strokeWidth="8"/>
  <path d="m24 18 8 8 8-8" fill="none" stroke={paint} strokeWidth="4" strokeLinecap="round" strokeLinejoin="round"/>
 </svg></div></div></>;
}
export function Majority(p:Props){const m=useMemo(()=>majorityLayout(p.seed,p.easy),[p.seed,p.easy]),[chosen,setChosen]=useState(-1);return <><p className="puzzle-instruction">Mitä väriä on eniten? Arvioi nopeasti!</p><div className={'majority-field '+(chosen>=0?'sorted':'')}>{m.items.map((v,i)=><span key={i} style={{color:inkColors[v],rotate:((i*37+p.seed)%50-25)+'deg'}}>{m.shape}</span>)}</div><div className="majority-options">{m.counts.map((n,i)=><button key={i} className={chosen<0?undefined:i===m.winner?'majority-winner':i===chosen?'majority-wrong':'majority-other'} style={{background:inkColors[i]}} aria-label={['Sininen','Vaaleanpunainen','Vihreä'][i]} onClick={()=>{if(p.blocked())return;setChosen(i);p.finish(i===m.winner?1000:0,`Eniten oli ${['sinisiä','vaaleanpunaisia','vihreitä'][m.winner]}: ${m.counts[m.winner]}.`);}}>{m.shape}{chosen>=0&&<small>{n}{i===m.winner?' ✓':i===chosen?' ×':''}</small>}</button>)}</div></>;
}
export function Slide(p:Props){const initial=useMemo(()=>slideLayout(p.seed,p.easy),[p.seed,p.easy]),minimum=useMemo(()=>slideMinimum(initial),[initial]),[blocks,setBlocks]=useState(initial),[selected,setSelected]=useState(0),[moves,setMoves]=useState(0),[offset,setOffset]=useState(0),[escaped,setEscaped]=useState(false);const current=useRef(initial),moved=useRef(0),drag=useRef<{id:number,pointer:number,start:number,cell:number,delta:number}|null>(null);
 const size=initial[0].grid??4,unit=100/size;
 function commit(i:number,d:number){if(p.blocked()||!d)return;let next=current.current,steps=0;for(let k=0;k<Math.abs(d);k++){const b=moveBlock(next,i,Math.sign(d));if(!b)break;next=b;steps++;}if(!steps)return;current.current=next;setBlocks(next);moved.current+=steps;setMoves(moved.current);if(next[0].x===size-next[0].len){setEscaped(true);p.finish(Math.max(100,1000-Math.max(0,moved.current-minimum)*70-Math.floor(p.ms/1000)*3),`Ulos päästiin ${moved.current} ruutuaskeleella! Paras reitti: ${minimum}.`);}}
 function begin(e:React.PointerEvent<HTMLButtonElement>,i:number){if(p.blocked()||drag.current)return;e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);const b=current.current[i],rect=e.currentTarget.parentElement!.getBoundingClientRect();drag.current={id:i,pointer:e.pointerId,start:b.axis==='h'?e.clientX:e.clientY,cell:(rect.width-10)/size,delta:0};setSelected(i);setOffset(0);}
 function track(e:React.PointerEvent<HTMLButtonElement>){const d=drag.current;if(!d||d.pointer!==e.pointerId||p.blocked())return;const axis=current.current[d.id].axis,raw=((axis==='h'?e.clientX:e.clientY)-d.start)/d.cell;let allowed=0,next=current.current;for(let k=0;k<Math.ceil(Math.abs(raw));k++){const b=moveBlock(next,d.id,Math.sign(raw));if(!b)break;allowed++;next=b;}d.delta=Math.sign(raw)*Math.min(Math.abs(raw),allowed);setOffset(d.delta);}
 function end(e:React.PointerEvent<HTMLButtonElement>,cancel=false){const d=drag.current;if(!d||d.pointer!==e.pointerId)return;if(!cancel)track(e);drag.current=null;setOffset(0);if(!cancel)commit(d.id,Math.round(d.delta));}
 return <><p className="puzzle-instruction">Vedä palikoita sormella. Vapauta punaiselle reitti ulos oikealta!</p><div className={'slide-board '+(escaped?'escaped ':'')+(size===5?'slide-five':'')}><svg className="slide-exit" viewBox="0 0 32 24" aria-hidden="true"><path d="M3 12h24m-8-8 8 8-8 8" fill="none" stroke="currentColor" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"/></svg>{blocks.map((b,i)=><button key={i} aria-label={i===0?'Punainen palikka':`Este ${i}`} aria-pressed={selected===i} className={'slide-block block-'+i+(drag.current?.id===i?' dragging':'')} style={{left:(b.x+(selected===i&&b.axis==='h'?offset:0))*unit+'%',top:(b.y+(selected===i&&b.axis==='v'?offset:0))*unit+'%',width:(b.axis==='h'?b.len:1)*unit+'%',height:(b.axis==='v'?b.len:1)*unit+'%'}} onPointerDown={e=>begin(e,i)} onPointerMove={track} onPointerUp={e=>end(e)} onPointerCancel={e=>end(e,true)} onLostPointerCapture={e=>end(e,true)} onKeyDown={e=>{const axis=b.axis,keys=axis==='h'?['ArrowLeft','ArrowRight']:['ArrowUp','ArrowDown'],d=keys.indexOf(e.key);if(d>=0){e.preventDefault();setSelected(i);commit(i,d===0?-1:1);}}}>{i===0?<span className="slide-face"><Face id={p.seed%6}/></span>:<span className={'block-grip '+b.axis} aria-hidden="true"><i/><i/><i/></span>}</button>)}</div><p className="puzzle-note">{moves} ruutuaskelta · Palikat liikkuvat pitkän sivunsa suuntaan.</p></>;
}
export function OneStroke(p:Props){const g=useMemo(()=>lineGraph(p.seed,p.easy),[p.seed,p.easy]),[path,setPath]=useState<number[]>([]),[hint,setHint]=useState('');const route=useRef<number[]>([]),used=useRef(new Set<number>()),active=useRef(false);
 function point(e:React.PointerEvent<SVGSVGElement>){const b=e.currentTarget.getBoundingClientRect(),x=(e.clientX-b.left)*300/b.width,y=(e.clientY-b.top)*300/b.height;let best=-1,dist=27;g.points.forEach((v,i)=>{const d=Math.hypot(v.x-x,v.y-y);if(d<dist){dist=d;best=i;}});return best;}
 function touch(e:React.PointerEvent<SVGSVGElement>,start=false){if(p.blocked())return;const i=point(e);if(start){if(i<0)return;e.currentTarget.setPointerCapture(e.pointerId);active.current=true;route.current=[i];used.current=new Set();setPath([i]);setHint('');return;}if(!active.current||i<0||route.current.at(-1)===i)return;const last=route.current.at(-1)!,edge=g.edges.findIndex(([a,b])=>a===last&&b===i||a===i&&b===last);if(edge<0||used.current.has(edge)){setHint('Sama viiva vain kerran. Aloita uudelleen!');active.current=false;return;}used.current.add(edge);route.current=[...route.current,i];setPath(route.current);if(used.current.size===g.edges.length){active.current=false;p.finish(1000,'Koko kuvio yhdellä vedolla!');}}
 return <><p className="puzzle-instruction">Piirrä kaikki viivat nostamatta sormea. Sama viiva vain kerran.</p><svg className="one-stroke-board" viewBox="0 0 300 285" preserveAspectRatio="none" onPointerDown={e=>touch(e,true)} onPointerMove={e=>touch(e)} onPointerUp={()=>{active.current=false;if(used.current.size<g.edges.length)setHint('Uusi yritys: aloita mistä tahansa pisteestä.');}} onPointerCancel={()=>active.current=false} aria-label="Yhden viivan piirtoalue">{g.edges.map(([a,b],i)=><line key={i} x1={g.points[a].x} y1={g.points[a].y} x2={g.points[b].x} y2={g.points[b].y} stroke="#76588e" strokeWidth="8"/>)}<path d={path.map((n,i)=>`${i?'L':'M'}${g.points[n].x} ${g.points[n].y}`).join(' ')} fill="none" stroke="#8cdeeb" strokeWidth="10" strokeLinecap="round" strokeLinejoin="round"/>{g.points.map((v,i)=><circle key={i} cx={v.x} cy={v.y} r="15" fill={path.at(-1)===i?'#f3a7cd':'#d1f87d'}/>)}</svg><p className="puzzle-note" role="status">{hint||'Viiva napsahtaa pisteisiin.'}</p></>;
}
export function Cups(p:Props){const n=p.easy?3:4,moves=useMemo(()=>cupMoves(p.seed,n),[p.seed,n]),step=Math.max(0,Math.min(10,Math.floor((p.ms-1500)/500)+1)),positions=cupPositions(moves,step,n),ball=p.seed%n,[chosen,setChosen]=useState(-1),shown=p.ms<1500||chosen>=0;return <><p className="puzzle-instruction">{p.ms<1500?'Muista, minkä kupin alla pallo on!':p.ms<6500?'Seuraa kuppia…':'Minkä kupin alla pallo on?'}</p><div className="cups-stage">{Array.from({length:n},(_,identity)=>{const slot=positions.indexOf(identity),lift=shown&&(identity===ball||identity===chosen);return <button key={identity} aria-label={`Kuppi ${slot+1}`} disabled={p.ms<6500||p.blocked()} style={{left:(slot+.5)*100/n+'%',width:90/n+'%','--cup-color':'#5de5ed'} as React.CSSProperties} className={lift?'lifted':''} onClick={()=>{if(p.blocked()||p.ms<6500)return;setChosen(identity);p.finish(identity===ball?1000:0,identity===ball?'Pallo löytyi — poks!':'Hupsista! Pallo piilotteli toisen kupin alla.');}}>{identity===ball&&shown&&<span className="cup-ball"/>}<span className="cup-shell">★</span></button>;})}</div><p className="puzzle-note">{p.ms<6500?'Kupit pysähtyvät ennen vastaamista.':'Napauta yhtä kuppia.'}</p></>;
}
export function Bisect(p:Props){const poly=useMemo(()=>polygon(p.seed,p.easy),[p.seed,p.easy]),[line,setLine]=useState<P[]>([]),[ratio,setRatio]=useState<number|null>(null),[hint,setHint]=useState('');const start=useRef<P|null>(null);const pos=(e:React.PointerEvent<SVGSVGElement>)=>{const b=e.currentTarget.getBoundingClientRect();return {x:(e.clientX-b.left)*300/b.width,y:(e.clientY-b.top)*300/b.height};};const pts=(a:P[])=>a.map(v=>`${v.x},${v.y}`).join(' ');
 return <><p className="puzzle-instruction">Leikkaa kuvio suoralla viivalla kahteen yhtä suureen osaan.</p><svg className="bisect-board" viewBox="0 0 300 300" aria-label="Kuvion puolitusalue" onPointerDown={e=>{if(p.blocked())return;e.currentTarget.setPointerCapture(e.pointerId);start.current=pos(e);setLine([start.current,start.current]);}} onPointerMove={e=>{if(start.current&&!p.blocked())setLine([start.current,pos(e)]);}} onPointerCancel={()=>start.current=null} onPointerUp={e=>{if(!start.current||p.blocked())return;const a=start.current,b=pos(e);start.current=null;const r=splitRatio(poly,a,b);if(r===null){setHint('Vedä viiva kuvion läpi. Voit aloittaa ulkopuolelta.');return;}setLine([a,b]);setRatio(r);p.finish(1000*(1-2*Math.abs(.5-r)),`${Math.round(r*100)} % / ${100-Math.round(r*100)} % — ${Math.abs(.5-r)<.06?'melkein tasan!':'hyvä yritys!'}`);}}><defs><linearGradient id="split-fill" x2="100%" y2="100%"><stop stopColor={['#b99bea','#86dcec','#f7a6cd'][Math.abs(p.seed)%3]}/><stop offset="1" stopColor={['#eea5d5','#b6ee89','#ffcf7f'][Math.abs(p.seed)%3]}/></linearGradient></defs><polygon points={pts(poly)} fill="url(#split-fill)" stroke="#fff1db" strokeWidth="3" strokeLinejoin="round"/>{ratio!==null&&line.length===2&&[1,-1].map((side,i)=><polygon key={side} points={pts(clipPolygon(poly,line[0],line[1],side))} fill={i?'#f2a4ce':'#8edfe9'} transform={`translate(${side*4},${side*4})`}/>)}{line.length===2&&<line x1={line[0].x} y1={line[0].y} x2={line[1].x} y2={line[1].y} stroke="#e0ff89" strokeWidth="5" strokeLinecap="round"/>}</svg><p className="puzzle-note" role="status">{hint||'Nosta sormi, kun leikkaus on valmis.'}</p></>;
}
export function Tilt(p:Props&{active:boolean,onStart:()=>void}){
 const maze=useMemo(()=>windingMaze(p.seed,p.easy),[p.seed,p.easy]),[pos,setPos]=useState({x:.5,y:.5}),[trail,setTrail]=useState<P[]>([]),[arrived,setArrived]=useState(false),[hint,setHint]=useState(''),[waiting,setWaiting]=useState(false),[sensor,setSensor]=useState(false),[canTilt,setCanTilt]=useState(false);const point=useRef({x:.5,y:.5}),velocity=useRef({x:0,y:0}),tilt=useRef({x:0,y:0}),angles=useRef<P|null>(null),neutral=useRef<P|null>(null),held=useRef(new Set<number>()),mounted=useRef(true),active=useRef(p.active),finish=useRef(p.finish),blocked=useRef(p.blocked);active.current=p.active;finish.current=p.finish;blocked.current=p.blocked;
 useEffect(()=>{mounted.current=true;const orient=(e:DeviceOrientationEvent)=>{if(e.beta===null||e.gamma===null)return;angles.current={x:e.gamma,y:e.beta};if(!neutral.current)neutral.current={...angles.current};tilt.current={x:Math.max(-1,Math.min(1,(e.gamma-neutral.current.x)/18)),y:Math.max(-1,Math.min(1,(e.beta-neutral.current.y)/18))};};window.addEventListener('deviceorientation',orient);const key=(e:KeyboardEvent)=>{const n=['ArrowUp','ArrowRight','ArrowDown','ArrowLeft'].indexOf(e.key);if(n>=0&&active.current){e.preventDefault();if(e.type==='keydown')held.current.add(n);else held.current.delete(n);}};window.addEventListener('keydown',key);window.addEventListener('keyup',key);const clear=()=>held.current.clear();window.addEventListener('blur',clear);return()=>{mounted.current=false;window.removeEventListener('deviceorientation',orient);window.removeEventListener('keydown',key);window.removeEventListener('keyup',key);window.removeEventListener('blur',clear);};},[]);
 useEffect(()=>{const tick=setInterval(()=>{if(!active.current||blocked.current())return;const n=maze.size,dir=held.current;const ax=sensor?tilt.current.x:dir.has(1)?1:dir.has(3)?-1:0,ay=sensor?tilt.current.y:dir.has(2)?1:dir.has(0)?-1:0;velocity.current.x=velocity.current.x*.84+ax*.035;velocity.current.y=velocity.current.y*.84+ay*.035;
 for(let k=0;k<5;k++)point.current=moveMarble(maze,point.current,{x:velocity.current.x/5,y:velocity.current.y/5},.23);
 const v=point.current;if(Math.hypot(v.x-(n-.5),v.y-(n-.5))<.39){setArrived(true);finish.current(1000,'Kuula sujahti maalireikään — spläsh!');}setTrail(a=>[...a.slice(-7),{...v}]);setPos({...v});},30);return()=>clearInterval(tick);},[maze,sensor]);
 async function begin(useSensor:boolean){if(waiting||p.active)return;setWaiting(true);let enabled=useSensor;try{const eventType=DeviceOrientationEvent as unknown as {requestPermission?:()=>Promise<string>};if(useSensor&&eventType.requestPermission){const permission=await eventType.requestPermission();if(permission!=='granted'){enabled=false;setHint('Liikelupaa ei annettu. Ohjaa nuolista.');}}}catch{enabled=false;setHint('Kallistus ei ole käytettävissä. Ohjaa nuolista.');}if(!mounted.current)return;neutral.current=angles.current?{...angles.current}:null;setSensor(enabled);setCanTilt(enabled);setWaiting(false);p.onStart();}
 function calibrate(){neutral.current=angles.current?{...angles.current}:null;tilt.current={x:0,y:0};velocity.current={x:0,y:0};}
 function changeControls(){held.current.clear();calibrate();setSensor(!sensor);setHint('');}
 const n=maze.size,cell=300/n;
 return <><p className="puzzle-instruction">{p.active?(sensor?'Kallista ja kuljeta kuula maalireikään!':'Ohjaa kuula nuolilla maalireikään!'):'Pidä puhelin mukavassa asennossa. Aloita, kun olet valmis.'}</p><svg className="tilt-board" viewBox="0 0 300 300" aria-label="Kuulalabyrintti"><defs><linearGradient id="maze-floor" x2="100%" y2="100%"><stop stopColor="#334a61"/><stop offset="1" stopColor="#503356"/></linearGradient><radialGradient id="marble-shine" cx="30%" cy="25%"><stop stopColor="#fff7db"/><stop offset=".4" stopColor="#f5b3d5"/><stop offset="1" stopColor="#a56fce"/></radialGradient></defs><rect width="300" height="300" fill="url(#maze-floor)"/>{maze.walls.map((w,i)=>{const x=i%n*cell,y=Math.floor(i/n)*cell;return <g key={i}>{w[0]&&<line x1={x} y1={y} x2={x+cell} y2={y} stroke="#b7a3e8" strokeWidth="5" strokeLinecap="round"/>}{w[3]&&<line x1={x} y1={y} x2={x} y2={y+cell} stroke="#b7a3e8" strokeWidth="5" strokeLinecap="round"/>}</g>;})}<rect x="2" y="2" width="296" height="296" rx="14" fill="none" stroke="#b7a3e8" strokeWidth="5" strokeLinecap="round"/><circle className="marble-goal-ring" cx={(n-.5)*cell} cy={(n-.5)*cell} r={cell*.43} fill="none" stroke="#cafa70" strokeWidth="2"/><circle cx={(n-.5)*cell} cy={(n-.5)*cell} r={cell*.38} fill="#100d1b" stroke="#8a6b99" strokeWidth="2"/>{trail.map((v,i)=><circle key={i} cx={v.x*cell} cy={v.y*cell} r={cell*.14*i/8} fill="#efaed9" opacity={i*.035}/>)}<g className={arrived?'marble-arrived':''} style={{transformOrigin:`${pos.x*cell}px ${pos.y*cell}px`}}><circle cx={pos.x*cell} cy={pos.y*cell+1} r={cell*.24} fill="#1a1028" opacity=".5"/><circle cx={pos.x*cell} cy={pos.y*cell} r={cell*.23} fill="url(#marble-shine)" stroke="#ffe7f6" strokeWidth="1"/><circle cx={pos.x*cell-cell*.05} cy={pos.y*cell-cell*.07} r={cell*.035} fill="#fff"/></g>{arrived&&<g className="marble-splash" style={{transformOrigin:`${(n-.5)*cell}px ${(n-.5)*cell}px`}}>{Array.from({length:8},(_,i)=><circle key={i} cx={(n-.5)*cell+Math.cos(i*Math.PI/4)*cell*.45} cy={(n-.5)*cell+Math.sin(i*Math.PI/4)*cell*.45} r="3" fill={inkColors[i%3]}/>)}</g>}</svg>
 {!p.active?<div className="tilt-start"><button className="primary" disabled={waiting} onClick={()=>void begin(true)}>Aloita kallistuksella →</button><button disabled={waiting} onClick={()=>void begin(false)}>Pelaa nuolipainikkeilla</button></div>:<>{!sensor&&<div className="tilt-controls">{['↑','→','↓','←'].map((s,i)=><button key={s} aria-label={['Ohjaa ylös','Ohjaa oikealle','Ohjaa alas','Ohjaa vasemmalle'][i]} onPointerDown={e=>{e.preventDefault();e.currentTarget.setPointerCapture(e.pointerId);held.current.add(i);}} onPointerUp={()=>held.current.delete(i)} onPointerCancel={()=>held.current.delete(i)} onLostPointerCapture={()=>held.current.delete(i)} onKeyDown={e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();held.current.add(i);}}} onKeyUp={()=>held.current.delete(i)}>{s}</button>)}</div>}{sensor&&<button className="tilt-reset" onClick={calibrate}>Aseta keskiasento uudelleen</button>}{canTilt&&<button className="tilt-reset tilt-switch" onClick={changeControls}>{sensor?'Vaihda nuoliohjaukseen':'Vaihda kallistukseen'}</button>}</>}
 <p className="puzzle-note" role="status">{hint||(p.active&&!sensor?'Nuolia voi pitää pohjassa. Myös näppäimistön nuolet toimivat.':'')}</p></>;
}

export function CodeRoute(p:Props & {avatar:number}){
 const layout=useMemo(()=>codeLayout(p.seed),[p.seed]);
 const [queue,setQueue]=useState<number[]>([]);
 const [cursor,setCursor]=useState(-1);
 const [executed,setExecuted]=useState(0);
 const [cell,setCell]=useState(layout.start);
 const [failed,setFailed]=useState(-1);
 const [running,setRunning]=useState(false);
 const [solved,setSolved]=useState(false);
 const [hint,setHint]=useState('');
 const timer=useRef<ReturnType<typeof setTimeout>|null>(null);
 useEffect(()=>()=>{if(timer.current)clearTimeout(timer.current);},[]);

 function add(command:number){
  if(running||p.blocked())return;
  if(failed>=0){
   setQueue(queue.map((value,index)=>index===failed?command:value));
   setFailed(-1);
  }else if(queue.length-executed<20)setQueue([...queue,command]);
  setHint('');
 }
 function run(){
  if(running||p.blocked()||queue.length===executed)return;
  setRunning(true);
  setFailed(-1);
  setHint('');
  function advance(index:number,position:number){
   if(p.blocked())return;
   if(index===queue.length){
    setRunning(false);
    setCursor(-1);
    setHint('Tähti jäi vielä radalle. Lisää tai vaihda komentoja.');
    return;
   }
   const next=codeStep(layout,position,queue[index]);
   setCursor(index);
   if(next===null){
    setRunning(false);
    setQueue(queue.slice(0,index+1));
    setFailed(index);
    setHint('Hups! Valitse nuoli tilalle.');
    return;
   }
   setCell(next);
   setExecuted(index+1);
   if(next===layout.goal){
    setSolved(true);
    setRunning(false);
    setHint('Tähti löytyi!');
    p.finish(1000,'Hahmo löysi reitin tähdelle!');
    return;
   }
   timer.current=setTimeout(()=>advance(index+1,next),210);
  }
  timer.current=setTimeout(()=>advance(executed,cell),160);
 }

 const firstVisible=Math.max(0,executed-(running?1:0));
 return <div className="code-route">
  <p className="puzzle-instruction">Anna komennot ja paina Aja!</p>
  <div className={'code-board'+(failed>=0&&hint?' code-bump':'')+(solved?' code-win':'')} aria-label="Koodausrata">
   {Array.from(layout.tiles,(tile,index)=><span key={index} className={'code-tile code-'+(tile==='#'?'wall':tile==='G'?'goal':tile==='S'?'start':'floor')} aria-hidden="true">{tile==='G'?'★':''}</span>)}
   <div className="code-avatar" style={{left:cell%layout.size*100/layout.size+'%',top:Math.floor(cell/layout.size)*100/layout.size+'%'}} aria-hidden="true"><Character id={p.avatar} happy={solved}/></div>
   {solved&&<span className="code-splash" aria-hidden="true">✦ ★ ✦</span>}
  </div>
  <div className="code-queue" aria-label="Komennot">{queue.length>executed||running?queue.slice(firstVisible).map((command,offset)=>{const index=offset+firstVisible;return <button type="button" key={index} disabled={running||p.blocked()||index<executed} aria-label={`Komento ${index+1}: ${codeDirections[command].label}. Vaihda komento`} className={index===failed?'code-error':index===cursor?'code-current':''} onClick={()=>{setFailed(index);setHint('Valitse uusi suunta.');}}>{codeDirections[command].symbol}</button>}):<span>{executed?'Lisää seuraava nuoli':'Valitse ensimmäinen nuoli'}</span>}</div>
  <div className="code-keys">{[3,0,2,1].map(command=><button type="button" key={command} disabled={running||p.blocked()||(queue.length-executed>=20&&failed<0)} aria-label={codeDirections[command].label} onClick={()=>add(command)}>{codeDirections[command].symbol}</button>)}</div>
  <div className="code-actions"><button type="button" aria-label="Poista viimeinen komento" disabled={queue.length===executed||running||p.blocked()} onClick={()=>{setQueue(queue.slice(0,-1));setFailed(-1);setCursor(-1);setHint('');}}><svg width="30" height="24" viewBox="0 0 32 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><path d="M12 3h16a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H12L3 12Z"/><path d="m16 8 8 8m0-8-8 8"/></svg></button><button type="button" className="primary" disabled={queue.length===executed||running||p.blocked()} onClick={run}>Aja!</button></div>
  <p className="puzzle-note" role="status">{hint}</p>
 </div>;
}

const sortColors=[
 {name:'Violetti',color:'#c2a0ff'},
 {name:'Sininen',color:'#78dfef'},
 {name:'Oranssi',color:'#ffab69'},
];

export function ColorSort(p:Props){
 const balls=useMemo(()=>shuffle([0,1,2,0,1,2,0,1,2],random(p.seed)),[p.seed]);
 const [sorted,setSorted]=useState<number[]>([]);
 const [selected,setSelected]=useState<number|null>(null);
 const [drag,setDrag]=useState<{x:number,y:number}|null>(null);
 const [returning,setReturning]=useState<{index:number,x:number,y:number}|null>(null);
 const [hint,setHint]=useState('');
 const placed=useRef<number[]>([]);
 const pointer=useRef<{id:number,index:number,x:number,y:number}|null>(null);
 const baskets=useRef<HTMLDivElement>(null);

 function drop(index:number,basket:number){
  if(p.blocked()||placed.current.includes(index))return;
  setSelected(null);
  if(balls[index]!==basket){setHint('Hups! Kokeile samanväristä koria.');return;}
  placed.current=[...placed.current,index];
  setSorted(placed.current);
  setHint('Poks!');
  if(placed.current.length===balls.length)p.finish(1000,'Kaikki pallot omissa koreissaan!');
 }

 return <div className="color-sort">
  <p className="puzzle-instruction">Vedä pallot samanvärisiin koreihin.</p>
  <div className="color-sort-balls">
   {balls.map((color,index)=><button type="button" key={index} disabled={sorted.includes(index)||p.blocked()} aria-label={`${sortColors[color].name} pallo ${index+1}`} aria-pressed={selected===index} className={sorted.includes(index)?'sort-placed':drag&&selected===index?'sort-held':returning?.index===index?'sort-returning':undefined} style={{'--sort-color':sortColors[color].color,'--return-x':returning?.index===index?returning.x+'px':undefined,'--return-y':returning?.index===index?returning.y+'px':undefined} as React.CSSProperties}
    onClick={event=>{if(event.detail===0)setSelected(index);}}
    onPointerDown={event=>{
     if(event.button!==0||pointer.current||p.blocked())return;
     event.preventDefault();
     event.currentTarget.setPointerCapture(event.pointerId);
     const rect=event.currentTarget.getBoundingClientRect();
     pointer.current={id:event.pointerId,index,x:rect.left+rect.width/2,y:rect.top+rect.height/2};
     setReturning(null);
     setSelected(index);
     setDrag({x:event.clientX,y:event.clientY});
    }}
    onPointerMove={event=>{
     const active=pointer.current;
     if(!active||event.pointerId!==active.id)return;
     setDrag({x:event.clientX,y:event.clientY});
    }}
    onPointerUp={event=>{
     const active=pointer.current;
     if(!active||event.pointerId!==active.id)return;
     pointer.current=null;
     setDrag(null);
     const target=document.elementFromPoint(event.clientX,event.clientY)?.closest<HTMLElement>('[data-sort-basket]');
     const basket=target&&baskets.current?.contains(target)?Number(target.dataset.sortBasket):null;
     if(basket!==balls[index])setReturning({index,x:event.clientX-active.x,y:event.clientY-active.y});
     if(basket!==null)drop(index,basket);
     else setSelected(null);
    }}
    onPointerCancel={event=>{
     if(pointer.current?.id!==event.pointerId)return;
     pointer.current=null;
     setDrag(null);
     setSelected(null);
    }}
    onLostPointerCapture={()=>{if(pointer.current?.index===index){pointer.current=null;setDrag(null);setSelected(null);}}}
   />)}
  </div>
  <div className="color-sort-baskets" ref={baskets}>
   {sortColors.map((color,index)=><button type="button" key={color.name} data-sort-basket={index} aria-label={`${color.name} kori`} style={{'--sort-color':color.color} as React.CSSProperties} onClick={()=>{if(selected!==null)drop(selected,index);}}>
    <span className="sort-splash" aria-hidden="true" key={sorted.filter(i=>balls[i]===index).length}>{sorted.some(i=>balls[i]===index)?'✦':''}</span>
   </button>)}
  </div>
  {drag&&selected!==null&&<span className="sort-drag" aria-hidden="true" style={{left:drag.x,top:drag.y,background:sortColors[balls[selected]].color}}/>}
  <p className="puzzle-note" role="status">{sorted.length} / {balls.length} {hint}</p>
 </div>;
}
