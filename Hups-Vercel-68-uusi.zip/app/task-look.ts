import {extraCatalog} from '../extra-tasks';
export const taskActions:Record<string,string>={scratch:'Raaputa yllätys esiin!',spray:'Suihki oikeaa väriä!',peek:'Kukkuu - nappaa hahmo!',
timer:'Pysäytä oikealla hetkellä!',circle:'Pyöräytä täydellinen ympyrä!',pictures:'Nappaa kolme tuttua kuvaa!',odd:'Löydä joukon outolintu!',colors:'Muista rytmi. Toista värit.',line:'Piirrä yhtä pitkä!',reaction:'Vihreällä mennään!',dots:'Montako palloa vilahti?',center:'Osu ihan keskelle!',target:'Täsmää napakymppiin!',sort:'Pienestä suureen!',biggest:'Nappaa suurin!',smallest:'Nappaa pienin!',more:'Kummalla on enemmän?',missing:'Mikä numero puuttuu?',add:'Nappaa oikea summa!',subtract:'Paljonko jää jäljelle?',shape:'Mikä muoto vilahti?',spot:'Muistatko pisteen paikan?',longest:'Nappaa pisin palkki!',shortest:'Nappaa lyhin palkki!',stars:'Löydätkö kaikki tähdet?',same:'Etsi mallin kaksonen!',opposite:'Käännä suunta!',gone:'Kuka katosi joukosta?',picorder:'Muista kuvat. Toista jono.',stop:'Pysäytä napakymppiin!',bubbles:'Poksa, poksa, poks!',pair:'Nappaa samanlainen pari!',digits:'Mikä luku vilahti?',taps:'Napauta tasan oikea määrä!',alternate:'Lue sana. Valitse puoli!',descend:'Suuresta pieneen!',middle:'Nappaa keskimmäinen!',near10:'Kuka on lähimpänä kymppiä?',numsequence:'Muista numerorytmi!',shortword:'Nappaa lyhin sana!',longword:'Nappaa pisin sana!',triangles:'Montako kolmiota?',colorword:'Lue sana, nappaa väri!',duplicate:'Kuka tuli kahdesti?',equal:'Löydä yhtä suuri joukko!',redcount:'Vain punaiset lasketaan!',sides:'Montako kulmaa löydät?',aimchain:'Kuusi osumaa putkeen!',smallball:'Pikkuisin pallo mukaan!',bigball:'Nappaa jättipallo!',gridmemory:'Sytytä samat kolme ruutua!',flashes:'Montako välähdystä?',lettergap:'Täydennä kirjainjono!',hidepics:'Kenen paikka tämä oli?',ink:'Nappaa musteen väri!',even:'Löydä parillinen!',double:'Tuplaa vauhdilla!',half:'Puolita luku!',nextpattern:'Jatka kuviorytmiä!',alphabet:'Kuka on aakkosissa ensin?',animal:'Nappaa eläin!',fruit:'Nappaa hedelmä tai marja!',reversepics:'Kuvat takaperin!',shadow:'Kenelle varjo kuuluu?',differences:'Kolme eroa. Löydä kaikki!'
};
export const colorSymbols=['★','≈','ϟ','❧'];

Object.assign(taskActions,Object.fromEntries(extraCatalog.map(t=>[t.id,t.action])));

taskActions.colorhunt='Siniset poks!';

taskActions.movinghunt='Poksauta siniset karkulaiset!';taskActions.movingcenter='Nappaa liikkuva napakymppi!';taskActions.movingspot='Mihin karkulainen katosi?';

Object.assign(taskActions,{colorsort:'Pallot omiin koreihin!',syllables:'Kuuntele sana mielessäsi!',coderoute:'Ohjaa hahmo tähdelle!',memorypairs:'Etsi samat kuvaparit!',parcel:'Kenelle paketti kuuluu?',speedlights:'Pysy valojen vauhdissa!',pipes:'Maali virtaamaan!',majority:'Mitä on eniten?',slide:'Punainen palikka ulos!',onestroke:'Koko kuvio yhdellä vedolla!',cups:'Missä pallo piilee?',bisect:'Jaa kuvio puoliksi!',tilt:'Kuula maaliin!'});

taskActions.piecefill='Täytä kuvio paloilla!';
